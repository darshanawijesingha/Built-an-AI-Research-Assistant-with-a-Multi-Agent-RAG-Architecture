"""
main.py
────────
CLI entry point for the Agentic AI system.

Usage:
    python main.py
    python main.py --question "Why are elevator sales declining in Sri Lanka?"
    python main.py --demo
"""
import rich
import argparse
import sys
import time
from pathlib import Path

from rich.console import Console
from rich.panel   import Panel
from rich.table   import Table
from rich.rule    import Rule
from rich import print as rprint

from config.settings import settings
from core.pipeline   import run_pipeline

OUTPUT_ROOT = Path(__file__).resolve().parent / "outputs"

console = Console()

DEMO_QUESTIONS = [
    "Why are elevator sales declining in Sri Lanka?",
    "What are the latest trends in Sri Lanka's construction industry?",
    "How is customer churn impacting telecom companies in Asia in 2025?",
]

BANNER = """
╔══════════════════════════════════════════════════════════╗
║           🤖  AGENTIC AI RESEARCH SYSTEM  🤖             ║
║                                                          ║
║   Supervisor → Research → Retrieval → [Analytics]       ║
║              → Validation → Answer                      ║
║                                                          ║
║   Powered by:  Groq LLM  ·  SerpAPI  ·  LangGraph       ║
╚══════════════════════════════════════════════════════════╝
"""


def display_result(result: dict, elapsed: float) -> None:
    """Pretty-print the pipeline result using Rich."""

    validation = result.get("validation", {})
    queries    = result.get("search_queries", [])
    chunks     = result.get("evidence_chunks", [])
    run_id     = result.get("run_id", "unknown")
    analytics  = result.get("analytics_result")

    # ── Pipeline summary table ────────────────────────────────────────
    table = Table(title="Pipeline Summary", show_header=True, header_style="bold cyan")
    table.add_column("Metric",  style="dim", width=28)
    table.add_column("Value",   style="bold")

    conf_score = validation.get("confidence_score", 0)
    conf_label = validation.get("confidence_label", "?")
    conf_color = {"High": "green", "Moderate": "yellow", "Low": "red"}.get(conf_label, "white")

    table.add_row("Run ID",                   f"[dim]{run_id}[/dim]")
    table.add_row("Search queries executed",  str(len(queries)))
    table.add_row("Evidence chunks retrieved",str(len(chunks)))
    table.add_row("Unique source domains",    str(validation.get("unique_sources", 0)))
    table.add_row("Source agreement",         validation.get("agreement_level", "?").title())
    table.add_row(
        "Confidence",
        f"[{conf_color}]{conf_label} ({conf_score})[/{conf_color}]",
    )
    table.add_row("Analytics computed",       "✅ Yes" if analytics else "⬜ No")
    table.add_row("Total time",               f"{elapsed:.1f}s")

    console.print(table)
    console.print()

    # ── Saved files notice ────────────────────────────────────────────
    saved_files = [
        f"outputs/runs/run_{run_id}.json",
        f"outputs/evidence/evidence_{run_id}.json",
    ]
    if analytics:
        saved_files.append(f"outputs/analytics/analytics_{run_id}.json")
    saved_files.append("outputs/sessions/session_*.json  (appended)")
    saved_files.append("outputs/summary_index.json       (updated)")

    save_table = Table(title="💾 Auto-Saved Outputs", show_header=False,
                       border_style="dim", padding=(0, 1))
    save_table.add_column("File", style="dim green")
    for f in saved_files:
        save_table.add_row(f"  {f}")
    console.print(save_table)
    console.print()

    # ── Search queries ────────────────────────────────────────────────
    if queries:
        console.print(Rule("[dim]Search Queries Used[/dim]"))
        for i, q in enumerate(queries, 1):
            rprint(f"  [dim]{i}.[/dim] {q}")
        console.print()

    # ── Sources ───────────────────────────────────────────────────────
    domains = validation.get("source_domains", [])
    if domains:
        console.print(Rule("[dim]Sources[/dim]"))
        domain_str = "  " + "  ·  ".join(domains[:8])
        rprint(f"[dim]{domain_str}[/dim]")
        console.print()

    # ── Final answer ──────────────────────────────────────────────────
    answer = result.get("final_answer", "No answer generated.")
    console.print(
        Panel(
            answer,
            title="[bold green]🔍 Research Answer[/bold green]",
            border_style="green",
            padding=(1, 2),
        )
    )


def interactive_loop() -> None:
    """Run the system in interactive REPL mode."""
    console.print(BANNER, style="bold blue")
    console.print("[dim]Type your question and press Enter. Type 'quit' to exit.[/dim]\n")

    while True:
        try:
            question = console.input("[bold cyan]❯ Your question: [/bold cyan]").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Goodbye.[/dim]")
            break

        if not question:
            continue
        if question.lower() in {"quit", "exit", "q"}:
            console.print("[dim]Goodbye.[/dim]")
            break

        console.print(f"\n[bold]Running pipeline for:[/bold] {question}\n")
        start = time.time()

        try:
            result = run_pipeline(question)
            elapsed = time.time() - start
            display_result(result, elapsed)
        except Exception as e:
            console.print(f"\n[bold red]Pipeline error:[/bold red] {e}")

        console.print("\n" + "─" * 60 + "\n")


def run_demo() -> None:
    """Run all demo questions sequentially."""
    console.print(BANNER, style="bold blue")
    console.print("[bold yellow]Running demo questions…[/bold yellow]\n")

    for i, question in enumerate(DEMO_QUESTIONS, 1):
        console.print(f"\n[bold cyan]Demo {i}/{len(DEMO_QUESTIONS)}:[/bold cyan] {question}\n")
        start = time.time()
        result = run_pipeline(question)
        elapsed = time.time() - start
        display_result(result, elapsed)
        console.print("\n" + "═" * 60 + "\n")


# ── Entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="Agentic AI Research System")
    parser.add_argument("--question", "-q", type=str, help="Run a single question and exit")
    parser.add_argument("--demo",           action="store_true", help="Run demo questions")
    args = parser.parse_args()

    # ── Validate API keys ─────────────────────────────────────────────
    try:
        settings.validate()
    except EnvironmentError as e:
        console.print(f"\n[bold red]Configuration error:[/bold red]\n{e}\n")
        sys.exit(1)

    if args.demo:
        run_demo()
    elif args.question:
        console.print(BANNER, style="bold blue")
        console.print(f"[bold]Question:[/bold] {args.question}\n")
        start = time.time()
        result = run_pipeline(args.question)
        elapsed = time.time() - start
        display_result(result, elapsed)
    else:
        interactive_loop()


if __name__ == "__main__":
    main()
