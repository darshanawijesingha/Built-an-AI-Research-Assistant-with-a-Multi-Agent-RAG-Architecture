"""
agents/discovery.py
────────────────────
Discovery Loop Agent — auto-discovers entities and does deep evidence extraction.
"""

from core.state import AgentState
from core.llm import call_llm_json
from tools.serp_search import search_multiple
from tools.source_tracker import source_tracker
from agents.retrieval import retrieve_top_chunks

DISCOVERY_SYS = """
You are an expert at extracting named entities from research evidence.
Given a question, evidence snippets, and an entity label, return a JSON list:
{{"entities": ["Entity1", "Entity2", ...]}}
Maximum {max_entities} entities. JSON only.
"""

ENTITY_QUERY_SYS = """
Generate 3 targeted search queries to find more detail about a specific entity.
Return JSON: {"queries": ["q1", "q2", "q3"]}
"""

def discovery_loop_agent(state: AgentState) -> AgentState:
    """Auto-discover entities and do deep evidence extraction per entity."""
    question = state["user_question"]
    plan = state.get("plan", {})
    chunks = state.get("evidence_chunks", [])
    # If no evidence chunks, return early
    if not chunks:
        print("[Discovery] No evidence chunks available, skipping entity discovery.")
        return {**state, "entities": [], "entity_deep_data": {}}
    
        # Only do discovery for complex questions
    if plan.get("complexity") == "simple":
        print("[Discovery] Simple question, skipping entity discovery.")
        return {**state, "entities": [], "entity_deep_data": {}}
    
    label = plan.get("entity_label", "Entity")
    geo = plan.get("geography", "")
    
    # Step 1: Discover entities from evidence
    evidence_text = "\n".join(
        f"- {c.get('title','')}: {c.get('snippet','')[:250]}"
        for c in chunks[:12]
    )
    
    result = call_llm_json(
        DISCOVERY_SYS.format(max_entities=12),
        f"Question: {question}\nEntity label: {label}\nGeography: {geo}\n\nEvidence:\n{evidence_text}"
    )
    entities = result.get("entities", [])[:12]
    
    if not entities:
        entities = [plan.get("topic_domain", question[:40])]
    
    # Step 2: Deep-loop per entity
    entity_deep_data = {}
    for entity in entities:
        # Generate entity-specific queries
        q_result = call_llm_json(
            ENTITY_QUERY_SYS,
            f"Entity: {entity}\nTopic: {question}\nGeography: {geo}"
        )
        sub_queries = q_result.get("queries", [])
        if not sub_queries:
            sub_queries = [
                f"{entity} {geo} price market",
                f"{entity} {plan.get('topic_domain','')} specifications data",
                f"{entity} official site {geo}",
            ]
        
        # Execute searches
        entity_hits = []
        for sq in sub_queries[:3]:
            hits = search_multiple([sq])
            source_tracker.add(hits, context=f"entity_loop:{entity}:{sq[:30]}")
            entity_hits.extend(hits)
        
        # Retrieve top chunks for this entity
        entity_evidence = retrieve_top_chunks(f"{entity} {question}", entity_hits, top_k=6)
        
        entity_deep_data[entity] = {
            "queries": sub_queries,
            "n_hits": len(entity_hits),
            "evidence": entity_evidence,
            "snippets": "\n".join(
                f"- {r.get('title','')}: {r.get('snippet','')[:200]}"
                for r in entity_evidence[:6]
            )
        }
    
    return {**state, "entities": entities, "entity_deep_data": entity_deep_data}