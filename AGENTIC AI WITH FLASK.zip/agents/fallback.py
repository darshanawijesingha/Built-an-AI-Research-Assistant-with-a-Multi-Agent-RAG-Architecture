"""
agents/fallback.py
───────────────────
Fallback agent that uses LLM knowledge when web search fails.
"""

from core.state import AgentState
from core.llm import call_llm

FALLBACK_PROMPT = """
You are a knowledgeable AI assistant. Web search is currently unavailable.

Answer the user's question based on your training knowledge.
Be honest about the limitations - state that this is based on your training data,
not real-time search results.

Format your answer with:
## Answer
[Direct answer]

## Key Points
- [Point 1]
- [Point 2]
- [Point 3]

## Note
This answer is based on training data. For the most current information,
web search would be needed.

User Question: {question}
"""

def fallback_agent(state: AgentState) -> AgentState:
    """Fallback agent that uses LLM knowledge when no search results exist."""
    question = state["user_question"]
    
    print("[Fallback] No search results available. Using LLM knowledge base.")
    
    response = call_llm(
        system_prompt="You are a knowledgeable AI assistant.",
        user_prompt=FALLBACK_PROMPT.format(question=question)
    )
    
    return {**state, "final_answer": response, "fallback_used": True}