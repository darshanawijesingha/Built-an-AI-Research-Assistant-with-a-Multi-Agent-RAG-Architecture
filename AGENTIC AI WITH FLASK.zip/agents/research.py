"""
agents/research.py
───────────────────
Research Agent — generates comprehensive search strategy with more queries.
"""

from core.state import AgentState
from core.llm import call_llm_json
from tools.serp_search import search_multiple
from tools.source_tracker import source_tracker
from config.settings import settings

SYSTEM_PROMPT = """
You are the Research Agent of an Agentic AI system conducting comprehensive market research.

Given a complex multi-part question, generate 5-8 **diverse, specific** Google search queries 
that together will retrieve the best evidence to answer ALL aspects of the question.

IMPORTANT: 
- Generate queries for different aspects of the question
- Include queries for: market size, key players, pricing, trends, specific countries
- Use 5-10 words per query
- Mix broad and specific queries

Respond ONLY with a valid JSON object:
{
  "queries": [
    "query 1",
    "query 2",
    "query 3",
    "query 4",
    "query 5"
  ],
  "search_focus_areas": ["area1", "area2", "area3"]
}

Rules:
- Generate 5-8 queries covering different angles
- Include at least one query about Sri Lanka if mentioned
- Include at least one query about global market trends
- Include at least one query about key players/manufacturers
"""


def research_agent(state: AgentState) -> AgentState:
    """LangGraph node: Research Agent with enhanced query generation."""
    question = state["user_question"]
    plan = state.get("plan", {})

    print(f"\n[Research] Generating comprehensive search strategy for complex query...")

    # Extract key themes from question for better search
    key_themes = []
    if "sri lanka" in question.lower():
        key_themes.append("Sri Lanka market")
    if "global" in question.lower() or "international" in question.lower():
        key_themes.append("global market")
    if "manufacturer" in question.lower() or "exporter" in question.lower():
        key_themes.append("manufacturers and exporters")
    if "price" in question.lower() or "pricing" in question.lower():
        key_themes.append("pricing and trends")
    if "profit" in question.lower():
        key_themes.append("profitability and financials")

    result = call_llm_json(
        system_prompt=SYSTEM_PROMPT,
        user_prompt=(
            f"User question: {question}\n"
            f"Key themes to cover: {', '.join(key_themes) if key_themes else 'general market research'}\n"
            f"Generate 5-8 diverse search queries to cover all aspects."
        ),
    )

    queries: list[str] = result.get("queries", [])
    
    # Ensure we have enough queries
    if len(queries) < 5:
        # Add fallback queries based on question
        base_queries = [
            question[:80],
            f"{question[:50]} market size",
            f"{question[:50]} key players",
            f"{question[:50]} trends",
        ]
        queries.extend(base_queries[:settings.MAX_SEARCH_QUERIES - len(queries)])
    
    # Limit queries
    queries = queries[:settings.MAX_SEARCH_QUERIES]

    print(f"[Research] Generated {len(queries)} search queries")
    for i, q in enumerate(queries, 1):
        print(f"  {i}. {q}")

    # Execute searches
    all_results: list[dict] = []
    seen_urls: set[str] = set()

    for qstr in queries:
        hits = search_multiple([qstr])
        source_tracker.add(hits, context=f"research:{qstr[:40]}")
        for hit in hits:
            url = hit.get("url", "")
            if url and url not in seen_urls:
                seen_urls.add(url)
                all_results.append(hit)

    # Sort by credibility
    all_results.sort(key=lambda x: x.get("credibility", {}).get("score", 0), reverse=True)

    print(f"[Research] Collected {len(all_results)} unique results "
          f"({source_tracker.unique_count()} total sources)")

    return {
        **state, 
        "search_queries": queries, 
        "raw_results": all_results,
        "search_focus_areas": result.get("search_focus_areas", [])
    }