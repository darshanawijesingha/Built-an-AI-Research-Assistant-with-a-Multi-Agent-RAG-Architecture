"""
agents/answer.py
─────────────────
Answer Agent — synthesises everything into a comprehensive, structured response.
"""

from core.state import AgentState
from core.llm import call_llm

SYSTEM_PROMPT = """
You are the Answer Agent of an Agentic AI research system.
Your role is to synthesise evidence and produce a comprehensive, well-structured response
to complex research questions.

FORMAT your response with the following sections:

## Executive Summary
[2-3 paragraph overview of the key findings]

## Market Overview
[Global market size, growth trends, key drivers]

## Sri Lankan Market Analysis
[If applicable - detailed analysis of the Sri Lankan market]

### Key Manufacturers and Exporters
[List major players with details]

### Production Capacity and Market Share
[Estimated production capacities and market share]

### Export Volumes and Destinations
[Export data and key destination markets]

### Product Pricing and Trends
[Current pricing and historical trends]

### Profitability Analysis
[Financial performance where available]

## International Market Analysis
[Global market analysis]

### Major Global Players
[List leading international manufacturers]

### Market Size and Growth
[Current market size and forecast]

### Production Volumes
[Global production data]

### Pricing Benchmarks
[International price benchmarks]

## Competitive Landscape
[Analysis of competition, barriers to entry]

## Key Insights
[5-7 bullet points of critical findings]

## Recommendations
[Strategic recommendations for a new entrant]

## Sources and Methodology
[Brief note on sources used]

Rules:
- Be thorough and evidence-based
- Use specific data points and cite sources
- If data is limited for a section, acknowledge it
- Organize information logically
- Total response should be comprehensive (800-1500 words)
- Use the evidence provided to support all claims
- When citing sources, use [Source X] or mention the domain
"""

def answer_agent(state: AgentState) -> AgentState:
    """LangGraph node: Answer Agent with comprehensive response."""
    question = state["user_question"]
    chunks = state.get("evidence_chunks", [])
    analytics = state.get("analytics_result", {})
    validation = state.get("validation", {})
    fallback = state.get("fallback_used", False)
    plan = state.get("plan", {})

    print(f"\n[Answer] Synthesising comprehensive answer from {len(chunks)} evidence chunks…")
    
    if fallback or not chunks:
        print("[Answer] Using fallback mode")
        return {**state, "final_answer": generate_fallback_answer(question)}

    # ── Build detailed evidence summary ──────────────────────────────
    evidence_lines = []
    for i, c in enumerate(chunks[:15], 1):  # Use more chunks
        evidence_lines.append(
            f"[{i}] Source: {c.get('source', '?')}\n"
            f"     Title: {c.get('title', '')}\n"
            f"     URL: {c.get('url', '')}\n"
            f"     Snippet: {c.get('snippet', '')}\n"
            f"     Relevance: {c.get('relevance', 0):.2f}"
        )
    evidence_text = "\n\n".join(evidence_lines)

    # ── Build analytics summary ──────────────────────────────────────
    analytics_text = ""
    if analytics:
        parts = []
        insight = analytics.get("key_numerical_insight", "")
        if insight:
            parts.append(f"Numerical insight: {insight}")
        
        stats = analytics.get("descriptive_statistics", {})
        if stats:
            parts.append(
                f"Statistics: mean={stats.get('mean')}, "
                f"trend={stats.get('trend')}, "
                f"range=[{stats.get('min')} – {stats.get('max')}]"
            )
        
        extracted = analytics.get("llm_extracted_stats", [])
        if extracted:
            stat_lines = [f"  - {s['metric']}: {s['value']} ({s.get('context', '')})"
                          for s in extracted[:8]]
            parts.append("Extracted statistics:\n" + "\n".join(stat_lines))
        
        financial = analytics.get("financial_data", {})
        if financial:
            financial_parts = []
            for entity, data in financial.items():
                if data.get("prices"):
                    financial_parts.append(f"{entity}: {', '.join(data['prices'][:3])}")
            if financial_parts:
                parts.append("Financial data found for: " + "; ".join(financial_parts[:3]))
        
        analytics_text = "\n".join(parts)

    # ── Build validation summary ──────────────────────────────────────
    conf_score = validation.get("confidence_score", 0.5)
    conf_label = validation.get("confidence_label", "Moderate")
    agreement = validation.get("agreement_level", "moderate")
    n_sources = validation.get("unique_sources", 0)
    domains = validation.get("source_domains", [])

    validation_text = f"""
Confidence: {conf_label} ({conf_score:.2f})
Agreement between sources: {agreement}
Unique source domains: {n_sources}
Domains: {', '.join(domains[:10])}
Total evidence chunks: {len(chunks)}
"""

    # ── Identify market analysis context ──────────────────────────────
    is_market_analysis = any(term in question.lower() for term in 
                             ['market', 'industry', 'manufacturer', 'exporter', 'supplier', 'competitor'])
    
    if is_market_analysis:
        market_context = "This is a market analysis question. Focus on providing comprehensive market data, competitor analysis, and strategic insights."
    else:
        market_context = "Provide a thorough research-based answer."

    # ── Compose LLM prompt ────────────────────────────────────────────
    user_prompt = f"""
User Question: {question}

{market_context}

--- EVIDENCE ({len(chunks)} chunks) ---
{evidence_text}

--- ANALYTICS ---
{analytics_text if analytics_text else "No analytics computed."}

--- VALIDATION ---
{validation_text}

Please provide a comprehensive, well-structured answer covering all aspects of the question.
Use specific data points from the evidence and cite sources.
If certain data is not available, acknowledge this honestly.
"""

    final_answer = call_llm(
        system_prompt=SYSTEM_PROMPT,
        user_prompt=user_prompt,
    )

    print(f"[Answer] Generated comprehensive answer ({len(final_answer)} characters)")
    return {**state, "final_answer": final_answer}


def generate_fallback_answer(question: str) -> str:
    """Generate a fallback answer when no search results are available."""
    from core.llm import call_llm
    
    return call_llm(
        system_prompt="You are a knowledgeable research assistant. Provide a comprehensive answer based on your training knowledge.",
        user_prompt=f"""Provide a comprehensive answer to this research question:
        
{question}

Format your answer with clear sections and structure. If you don't have specific data for certain aspects, acknowledge this honestly."""
    )