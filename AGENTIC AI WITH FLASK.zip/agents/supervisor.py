"""
agents/supervisor.py
─────────────────────
Supervisor Agent — analyzes complex questions and creates research plan.
"""

from core.state import AgentState
from core.llm import call_llm_json

SYSTEM_PROMPT = """
You are the Supervisor Agent of an Agentic AI research system.

Analyze the user's question and create a comprehensive research plan.
For complex multi-part questions (like market analysis), plan to cover ALL aspects.

Return a JSON object with:
{
  "topic_domain": "string",
  "geography": "string",
  "question_type": "market_research | general_research | analytics",
  "complexity": "simple | moderate | complex",
  "needs_web_search": true,
  "needs_analytics": true,
  "needs_forecast": true,
  "needs_multi_aspect": true,
  "research_dimensions": [
    "market_size",
    "key_players",
    "pricing",
    "trends",
    "competitive_landscape",
    "export_data",
    "profitability",
    "regulatory"
  ],
  "search_focus": "comprehensive market research",
  "target_countries": ["Sri Lanka", "Global"],
  "key_aspects_to_cover": ["manufacturers", "exporters", "pricing", "growth"]
}

For market analysis questions:
- Set needs_multi_aspect = true
- Include all relevant research dimensions
- Set complexity based on number of aspects requested

Rules:
- For questions with multiple parts, identify all key aspects
- Set needs_analytics = true for any numeric/trend questions
- Set needs_forecast = true for growth/prediction questions
"""


def supervisor_agent(state: AgentState) -> AgentState:
    """LangGraph node: Supervisor Agent with enhanced planning."""
    question = state["user_question"]
    print(f"\n[Supervisor] Analyzing complex research question")

    plan = call_llm_json(
        system_prompt=SYSTEM_PROMPT,
        user_prompt=f"User question: {question}",
    )

    # ── Enhanced defaults for complex questions ──────────────────────
    is_market_analysis = any(term in question.lower() for term in 
                             ['market', 'industry', 'manufacturer', 'exporter', 'supplier'])
    
    if is_market_analysis:
        plan.setdefault("needs_multi_aspect", True)
        plan.setdefault("complexity", "complex")
        plan.setdefault("needs_analytics", True)
        plan.setdefault("needs_forecast", True)
        plan.setdefault("research_dimensions", [
            "market_size", "key_players", "pricing", "trends",
            "competitive_landscape", "export_data", "profitability"
        ])
        if "sri lanka" in question.lower():
            plan["target_countries"] = ["Sri Lanka", "Global"]
    
    # Ensure all defaults
    plan.setdefault("question_type", "general_research")
    plan.setdefault("needs_web_search", True)
    plan.setdefault("needs_analytics", True)
    plan.setdefault("needs_forecast", False)
    plan.setdefault("search_focus", question[:100])
    plan.setdefault("suggested_sources", ["web", "news", "scholar"])
    plan.setdefault("complexity", "moderate")
    plan.setdefault("topic_domain", "general")
    plan.setdefault("geography", "global")
    plan.setdefault("needs_multi_aspect", False)
    plan.setdefault("research_dimensions", ["general"])
    plan.setdefault("key_aspects_to_cover", ["overview"])

    print(f"[Supervisor] Plan → complexity: {plan.get('complexity')}, "
          f"dimensions: {plan.get('research_dimensions')}")

    return {**state, "plan": plan}