"""
agents/validation.py
─────────────────────
Validation Agent — cross-checks evidence before answering.

Responsibilities:
  • Measure source diversity (unique domains).
  • Ask the LLM to judge consistency across evidence chunks.
  • Compute a confidence score (0.0 – 1.0).
  • Write a validation dict into AgentState["validation"].

Confidence formula:
  base    = 0.40  (always)
  +0.20   if ≥ MIN_SOURCES_FOR_HIGH_CONFIDENCE distinct source domains
  +0.20 / +0.10  if LLM finds high / moderate agreement between sources
  +0.10   if ≥ 5 evidence chunks available
  +0.10   if analytics produced LLM-extracted stats
  + (avg_credibility * 0.2)  credibility-weighted bonus
  +0.25 / +0.15  extra bonus for ≥5 / ≥3 unique source domains
  +0.10   if ≥ 3 high-authority sources (credibility ≥ 0.80)
  capped at 1.0
"""

from statistics import mean
from urllib.parse import urlparse

from core.state import AgentState
from core.llm import call_llm_json
from config.settings import settings


AGREEMENT_PROMPT = """
You are a fact-checking assistant.

Given the evidence snippets below, assess whether they AGREE,
PARTIALLY AGREE, or CONTRADICT each other on the user's question.

Respond ONLY with JSON (no markdown):
{
  "agreement_level": "<high | moderate | low | contradictory>",
  "reason": "one sentence explaining your assessment"
}
"""


def _extract_domain(url: str) -> str:
    try:
        return urlparse(url).netloc.replace("www.", "")
    except Exception:
        return url


def validation_agent(state: AgentState) -> AgentState:
    """LangGraph node: Validation Agent."""
    question   = state["user_question"]
    chunks     = state.get("evidence_chunks", [])
    analytics  = state.get("analytics_result") or state.get("analytics") or {}

    print(f"\n[Validation] Cross-checking {len(chunks)} evidence chunks…")

    # ── Source diversity ──────────────────────────────────────────────
    domains = {_extract_domain(c.get("url", "")) for c in chunks if c.get("url")}
    unique_sources = len(domains)

    # ── LLM agreement check ───────────────────────────────────────────
    evidence_text = "\n\n".join(
        f"[{i+1}] ({c.get('source','?')}) {c.get('snippet','')}"
        for i, c in enumerate(chunks[:6])
    )

    agreement_result = call_llm_json(
        system_prompt=AGREEMENT_PROMPT,
        user_prompt=f"Question: {question}\n\nEvidence:\n{evidence_text}",
    )
    agreement_level = agreement_result.get("agreement_level", "moderate")
    agreement_reason = agreement_result.get("reason", "")

    # ── Confidence score (single, coherent pass) ────────────────────────
    confidence = 0.40

    if unique_sources >= settings.MIN_SOURCES_FOR_HIGH_CONFIDENCE:
        confidence += 0.20

    if agreement_level == "high":
        confidence += 0.20
    elif agreement_level == "moderate":
        confidence += 0.10

    if len(chunks) >= 5:
        confidence += 0.10

    if analytics.get("llm_extracted_stats"):
        confidence += 0.10

    # Credibility-weighted bonus
    cred_scores = [c.get("credibility", {}).get("score", 0) for c in chunks if c.get("credibility")]
    if cred_scores:
        confidence += mean(cred_scores) * 0.2

    # Extra source-diversity bonus
    if unique_sources >= 5:
        confidence += 0.25
    elif unique_sources >= 3:
        confidence += 0.15

    # Bonus from analytics source quality (high-authority sources)
    source_quality = analytics.get("source_quality", {})
    if source_quality.get("high_authority", 0) >= 3:
        confidence += 0.10

    confidence = round(min(confidence, 1.0), 2)

    # ── Confidence label ──────────────────────────────────────────────
    if confidence >= 0.80:
        label = "High"
    elif confidence >= 0.60:
        label = "Moderate"
    else:
        label = "Low"

    validation = {
        "confidence_score":  confidence,
        "confidence_label":  label,
        "unique_sources":    unique_sources,
        "source_domains":    sorted(domains),
        "agreement_level":   agreement_level,
        "agreement_reason":  agreement_reason,
        "total_chunks_used": len(chunks),
    }

    print(f"[Validation] Confidence={confidence} ({label}) | "
          f"Sources={unique_sources} | Agreement={agreement_level}")

    return {**state, "validation": validation}
