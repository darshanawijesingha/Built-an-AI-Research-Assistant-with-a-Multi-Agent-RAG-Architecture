"""
agents/retrieval.py
────────────────────
Retrieval Agent — the RAG layer.

Responsibilities:
  • Take raw SERP results from the Research Agent.
  • Run hybrid BM25 + semantic retrieval + RRF fusion.
  • Write the top-k most relevant evidence chunks into
    AgentState["evidence_chunks"].
"""

from core.state import AgentState
from tools.retriever import retrieve_top_chunks
from config.settings import settings


def retrieval_agent(state: AgentState) -> AgentState:
    """LangGraph node: Retrieval Agent."""
    question    = state["user_question"]
    raw_results = state.get("raw_results", [])

    print(f"\n[Retrieval] Re-ranking {len(raw_results)} results for relevance…")

    if not raw_results:
        print("[Retrieval] No raw results to rank.")
        return {**state, "evidence_chunks": []}

    chunks = retrieve_top_chunks(
        question=question,
        documents=raw_results,
        top_k=settings.TOP_K_CHUNKS,
    )

    print(f"[Retrieval] Selected top {len(chunks)} evidence chunks.")
    for i, c in enumerate(chunks[:3], 1):
        print(f"  [{i}] relevance={c['relevance']:.2f}  {c['title'][:60]}")

    return {**state, "evidence_chunks": chunks}
