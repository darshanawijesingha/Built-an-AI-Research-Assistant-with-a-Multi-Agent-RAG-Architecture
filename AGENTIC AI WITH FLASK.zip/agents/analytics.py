"""
agents/analytics.py
────────────────────
Analytics Agent — runs ONLY when the Supervisor sets needs_analytics=True.

Responsibilities:
  • Extract any numerical / financial data from evidence chunks
    (including per-entity deep-dive evidence from the Discovery Loop).
  • Compute descriptive statistics, trends, and source-quality metrics.
  • Ask the LLM to extract structured stats + a one-line insight.
  • Write a structured result into AgentState under both "analytics"
    and "analytics_result" (validation/answer/saver read either key).
"""

import re
from statistics import mean, median, stdev

from core.state import AgentState
from core.llm import call_llm_json


# ── Number extraction ───────────────────────────────────────────────────────

def _extract_numbers(text: str) -> list[float]:
    """Pull all numeric values (including % and decimals) from a string."""
    raw = re.findall(r"[-+]?\d+(?:,\d{3})*(?:\.\d+)?(?:%)?", text)
    numbers: list[float] = []
    for r in raw:
        clean = r.replace(",", "").replace("%", "")
        try:
            numbers.append(float(clean))
        except ValueError:
            pass
    return numbers


def _extract_numbers_from_evidence(evidence_chunks: list[dict]) -> list[float]:
    """Extract numbers across a list of evidence chunk dicts."""
    numbers: list[float] = []
    for chunk in evidence_chunks:
        text = f"{chunk.get('title', '')} {chunk.get('snippet', '')}"
        numbers.extend(_extract_numbers(text))
    return numbers


def _extract_financial_data(evidence_chunks: list, entity: str) -> dict:
    """Extract structured financial data mentioning a specific entity."""
    financial_data = {
        "prices": [], "percentages": [], "years": [],
        "quantities": [], "revenue_figures": [],
        "market_share": [], "growth_rates": [],
    }

    entity_lower = entity.lower()

    for chunk in evidence_chunks:
        text = f"{chunk.get('title', '')} {chunk.get('snippet', '')}"
        if entity_lower not in text.lower():
            continue

        price_patterns = [
            r'(?:LKR|Rs\.?|₹|Rs|\$|USD)\s*[\d,]+\.?\d*\s*(?:million|billion|k|K)?',
            r'[\d,]+\.?\d*\s*(?:LKR|Rupees|USD|dollars)',
        ]
        for pattern in price_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            financial_data["prices"].extend(matches[:3])

        pct_patterns = [
            r'[\d.]+%\s*(?:growth|increase|decrease|market share|CAGR)',
            r'(?:growth|increase|market share)[:\s]+[\d.]+%',
        ]
        for pattern in pct_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            financial_data["percentages"].extend(matches[:3])

        years = re.findall(r'\b(20\d{2})\b', text)
        financial_data["years"].extend(years)

    # Deduplicate while preserving order
    for key in financial_data:
        financial_data[key] = list(dict.fromkeys(financial_data[key]))

    return financial_data


def _linear_trend(values: list[float]) -> str:
    """Return 'increasing', 'decreasing', 'stable', or 'insufficient data'."""
    if len(values) < 2:
        return "insufficient data"
    n = len(values)
    xs = list(range(n))
    x_mean = mean(xs)
    y_mean = mean(values)
    numerator   = sum((x - x_mean) * (y - y_mean) for x, y in zip(xs, values))
    denominator = sum((x - x_mean) ** 2 for x in xs)
    if denominator == 0:
        return "stable"
    slope = numerator / denominator
    pct_change = abs(slope / y_mean * 100) if y_mean else 0
    if pct_change < 2:
        return "stable"
    return "increasing" if slope > 0 else "decreasing"


def _generate_insight(descriptive: dict, financial_by_entity: dict) -> str:
    """Produce a short fallback insight from computed stats when the LLM
    extraction doesn't provide one."""
    parts = []
    if descriptive:
        parts.append(
            f"Found {descriptive.get('count', 0)} numeric data points "
            f"(mean={descriptive.get('mean')}, trend={descriptive.get('trend')})."
        )
    entities_with_data = [e for e, d in financial_by_entity.items() if any(d.values())]
    if entities_with_data:
        parts.append(f"Financial figures found for: {', '.join(entities_with_data[:5])}.")
    return " ".join(parts) if parts else "No significant numerical data found."


EXTRACT_PROMPT = """
You are a data extraction assistant.

From the evidence text below, extract any statistics, percentages,
growth rates, revenue figures, or numerical trends relevant to
the user's question.

Respond ONLY with JSON (no markdown):
{
  "extracted_stats": [
    {"metric": "...", "value": "...", "context": "..."}
  ],
  "key_numerical_insight": "one sentence summarising the numbers"
}

If no useful numbers are found, return:
{"extracted_stats": [], "key_numerical_insight": "No numerical data found."}
"""


def analytics_agent(state: AgentState) -> AgentState:
    """LangGraph node: Analytics Agent (conditionally executed)."""
    question = state["user_question"]
    chunks = state.get("evidence_chunks", [])
    entity_deep_data = state.get("entity_deep_data", {})
    entities = state.get("discovered_entities", [])

    print(f"\n[Analytics] Running analytics on {len(chunks)} evidence chunks…")

    # ── Combine base evidence with per-entity deep-dive evidence ───────
    all_evidence = list(chunks)
    for ed in entity_deep_data.values():
        all_evidence.extend(ed.get("evidence", []))

    # ── Per-entity financial extraction ─────────────────────────────────
    financial_by_entity = {
        entity: _extract_financial_data(all_evidence, entity)
        for entity in entities
    }

    # ── LLM: extract structured stats + narrative insight ──────────────
    combined_text = "\n\n".join(
        f"[{i+1}] {c.get('title', '')}: {c.get('snippet', '')}"
        for i, c in enumerate(chunks[:8])
    )
    llm_result = call_llm_json(
        system_prompt=EXTRACT_PROMPT,
        user_prompt=f"Question: {question}\n\nEvidence:\n{combined_text}",
    )

    # ── Descriptive statistics over all evidence (base + entity deep-dive) ──
    all_numbers = _extract_numbers_from_evidence(all_evidence)
    descriptive: dict = {}
    if len(all_numbers) >= 2:
        descriptive = {
            "count":  len(all_numbers),
            "mean":   round(mean(all_numbers), 2),
            "median": round(median(all_numbers), 2),
            "min":    round(min(all_numbers), 2),
            "max":    round(max(all_numbers), 2),
            "stdev":  round(stdev(all_numbers), 2) if len(all_numbers) > 2 else 0,
            "trend":  _linear_trend(all_numbers),
        }

    # ── Source quality metrics ──────────────────────────────────────────
    cred_scores = [c.get("credibility", {}).get("score", 0) for c in all_evidence if c.get("credibility")]
    source_quality = {
        "total_sources": len(all_evidence),
        "unique_domains": len({
            c.get("credibility", {}).get("domain", "")
            for c in all_evidence if c.get("credibility")
        }),
        "avg_credibility": round(mean(cred_scores), 3) if cred_scores else 0,
        "high_authority": sum(1 for c in all_evidence if c.get("credibility", {}).get("score", 0) >= 0.80),
        "credible": sum(1 for c in all_evidence if c.get("credibility", {}).get("is_credible", False)),
    }

    key_insight = llm_result.get("key_numerical_insight") or _generate_insight(descriptive, financial_by_entity)

    analytics_result = {
        "llm_extracted_stats":    llm_result.get("extracted_stats", []),
        "key_numerical_insight":  key_insight,
        "descriptive_statistics": descriptive,
        "source_quality":         source_quality,
        "financial_data":         financial_by_entity,
    }

    print(f"[Analytics] Insight → {key_insight}")
    print(f"[Analytics] Stats   → {descriptive}")

    # Written under both keys: "analytics_result" (read by validation/answer/
    # saver/main.py) and "analytics" (read by validation's source-quality bonus).
    return {**state, "analytics_result": analytics_result, "analytics": analytics_result}
