"""
view_outputs.py
────────────────
A simple CLI tool to browse and read your saved outputs.

Usage:
    python view_outputs.py                  # show summary index
    python view_outputs.py --list           # list all runs
    python view_outputs.py --run <run_id>   # show full run
    python view_outputs.py --evidence <run_id>  # show evidence chunks
    python view_outputs.py --session        # show latest session
    python view_outputs.py --stats          # overall usage stats
"""

import argparse
import json
from pathlib import Path

from rich.console import Console
from rich.table   import Table
from rich.panel   import Panel
from rich.rule    import Rule
from rich import print as rprint

console   = Console()
OUT_ROOT  = Path(__file__).resolve().parent / "outputs"


def _load(path: Path) -> dict | None:
    if not path.exists():
        console.print(f"[red]File not found:[/red] {path}")
        return None
    return json.loads(path.read_text(encoding="utf-8"))


# ── Commands ──────────────────────────────────────────────────────────────────

def show_index() -> None:
    """Print summary_index.json as a table."""
    data = _load(OUT_ROOT / "summary_index.json")
    if not data:
        console.print("[yellow]No runs saved yet. Ask a question first![/yellow]")
        return

    table = Table(
        title=f"📋 All Runs  (total: {data.get('total_runs', 0)})",
        show_header=True, header_style="bold cyan",
    )
    table.add_column("#",           width=4,  style="dim")
    table.add_column("Run ID",      width=24, style="dim")
    table.add_column("Question",    width=45)
    table.add_column("Confidence",  width=14)
    table.add_column("Sources",     width=8)
    table.add_column("Timestamp",   width=20, style="dim")

    for i, run in enumerate(reversed(data.get("runs", [])), 1):
        label = run.get("confidence_label", "?")
        score = run.get("confidence_score", 0)
        color = {"High": "green", "Moderate": "yellow", "Low": "red"}.get(label, "white")
        table.add_row(
            str(i),
            run.get("run_id", ""),
            run.get("question", "")[:44],
            f"[{color}]{label} ({score})[/{color}]",
            str(run.get("unique_sources", 0)),
            run.get("timestamp", "")[:19],
        )

    console.print(table)
    console.print(f"\n[dim]Last updated: {data.get('last_updated', 'N/A')}[/dim]")


def show_run(run_id: str) -> None:
    """Print a full run file."""
    data = _load(OUT_ROOT / "runs" / f"run_{run_id}.json")
    if not data:
        return

    console.print(Panel(
        f"[bold]{data.get('question', '')}[/bold]",
        title=f"[cyan]Run {run_id}[/cyan]",
        subtitle=data.get("timestamp", ""),
    ))

    # Validation
    v = data.get("validation", {})
    label = v.get("confidence_label", "?")
    color = {"High": "green", "Moderate": "yellow", "Low": "red"}.get(label, "white")
    rprint(f"\n[bold]Confidence:[/bold] [{color}]{label} ({v.get('confidence_score')})[/{color}]")
    rprint(f"[bold]Sources:[/bold]    {v.get('unique_sources', 0)} unique domains")
    rprint(f"[bold]Agreement:[/bold]  {v.get('agreement_level', '?').title()}")
    rprint(f"[bold]Chunks:[/bold]     {v.get('total_chunks_used', 0)} evidence pieces used")

    # Search queries
    console.print(Rule("[dim]Search Queries[/dim]"))
    for i, q in enumerate(data.get("search_queries", []), 1):
        rprint(f"  [dim]{i}.[/dim] {q}")

    # Answer
    console.print(Rule("[dim]Answer[/dim]"))
    console.print(Panel(data.get("answer", ""), border_style="green", padding=(1, 2)))


def show_evidence(run_id: str) -> None:
    """Print evidence chunks for a run."""
    data = _load(OUT_ROOT / "evidence" / f"evidence_{run_id}.json")
    if not data:
        return

    console.print(f"\n[bold cyan]Evidence for:[/bold cyan] {data.get('question', '')}")
    console.print(f"[dim]Total chunks: {data.get('total_chunks', 0)}[/dim]\n")

    for chunk in data.get("evidence_chunks", []):
        rank      = chunk.get("rank", "?")
        relevance = chunk.get("relevance", 0)
        color     = "green" if relevance > 0.7 else "yellow" if relevance > 0.4 else "red"
        console.print(Rule(
            f"[{color}]#{rank}  relevance={relevance:.2f}[/{color}]  {chunk.get('source', '')}"
        ))
        rprint(f"[bold]{chunk.get('title', '')}[/bold]")
        rprint(f"[dim]{chunk.get('url', '')}[/dim]")
        rprint(f"{chunk.get('snippet', '')}\n")


def show_latest_session() -> None:
    """Print the most recent session file."""
    session_dir = OUT_ROOT / "sessions"
    if not session_dir.exists():
        console.print("[yellow]No sessions saved yet.[/yellow]")
        return

    sessions = sorted(session_dir.glob("session_*.json"))
    if not sessions:
        console.print("[yellow]No session files found.[/yellow]")
        return

    data = _load(sessions[-1])
    if not data:
        return

    console.print(Panel(
        f"Session ID: {data.get('session_id', '')}\n"
        f"Started:    {data.get('started_at', '')}\n"
        f"Questions:  {data.get('total_questions', 0)}",
        title="[cyan]Latest Session[/cyan]",
    ))

    for i, q in enumerate(data.get("questions", []), 1):
        label = q.get("confidence_label", "?")
        color = {"High": "green", "Moderate": "yellow", "Low": "red"}.get(label, "white")
        console.print(Rule(f"[bold]Q{i}[/bold]"))
        rprint(f"[bold]Question:[/bold]   {q.get('question', '')}")
        rprint(f"[bold]Confidence:[/bold] [{color}]{label} ({q.get('confidence_score')})[/{color}]")
        rprint(f"[bold]Run ID:[/bold]     [dim]{q.get('run_id', '')}[/dim]")
        rprint(f"\n{q.get('answer', '')[:300]}{'…' if len(q.get('answer','')) > 300 else ''}\n")


def show_stats() -> None:
    """Show overall usage statistics."""
    data = _load(OUT_ROOT / "summary_index.json")
    if not data or not data.get("runs"):
        console.print("[yellow]No runs saved yet.[/yellow]")
        return

    runs = data["runs"]
    scores      = [r["confidence_score"] for r in runs if "confidence_score" in r]
    high_count  = sum(1 for r in runs if r.get("confidence_label") == "High")
    mod_count   = sum(1 for r in runs if r.get("confidence_label") == "Moderate")
    low_count   = sum(1 for r in runs if r.get("confidence_label") == "Low")
    avg_sources = sum(r.get("unique_sources", 0) for r in runs) / len(runs)

    table = Table(title="📊 Usage Statistics", show_header=True, header_style="bold cyan")
    table.add_column("Metric", style="dim", width=30)
    table.add_column("Value",  style="bold")

    table.add_row("Total questions asked",    str(len(runs)))
    table.add_row("Avg confidence score",     f"{sum(scores)/len(scores):.2f}" if scores else "N/A")
    table.add_row("High confidence answers",  f"[green]{high_count}[/green]")
    table.add_row("Moderate confidence",      f"[yellow]{mod_count}[/yellow]")
    table.add_row("Low confidence answers",   f"[red]{low_count}[/red]")
    table.add_row("Avg unique sources/query", f"{avg_sources:.1f}")

    console.print(table)

    # Analytics-enabled questions
    analytics_dir = OUT_ROOT / "analytics"
    if analytics_dir.exists():
        n_analytics = len(list(analytics_dir.glob("analytics_*.json")))
        rprint(f"\n[dim]Analytics computed for {n_analytics} / {len(runs)} questions.[/dim]")


# ── Entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="Browse saved Agentic AI outputs")
    parser.add_argument("--list",     action="store_true", help="List all runs (summary index)")
    parser.add_argument("--run",      type=str,            help="Show full run by run_id")
    parser.add_argument("--evidence", type=str,            help="Show evidence chunks by run_id")
    parser.add_argument("--session",  action="store_true", help="Show latest session")
    parser.add_argument("--stats",    action="store_true", help="Show overall usage stats")
    args = parser.parse_args()

    if args.run:
        show_run(args.run)
    elif args.evidence:
        show_evidence(args.evidence)
    elif args.session:
        show_latest_session()
    elif args.stats:
        show_stats()
    else:
        # Default: show the index
        show_index()


if __name__ == "__main__":
    main()
