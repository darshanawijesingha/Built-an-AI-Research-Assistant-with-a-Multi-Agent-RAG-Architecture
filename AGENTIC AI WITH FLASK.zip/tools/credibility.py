"""
tools/credibility.py
─────────────────────
Domain-tier credibility scoring for source evaluation.
"""

from urllib.parse import urlparse
from typing import Dict, List

class CredibilityManager:
    TIERS: Dict[float, List[str]] = {
        1.00: ['un.org', 'who.int', 'worldbank.org', 'imf.org', 'nature.com'],
        0.90: ['gov.lk', 'gov.uk', 'cdc.gov', 'nih.gov', 'europa.eu'],
        0.85: ['harvard.edu', 'stanford.edu', 'mit.edu', 'ox.ac.uk'],
        0.80: ['reuters.com', 'bloomberg.com', 'ft.com', 'economist.com'],
        0.75: ['bbc.com', 'apnews.com', 'aljazeera.com'],
        0.65: ['wikipedia.org'],
    }
    
    TLD_BONUS = {'.edu': 0.85, '.gov': 0.90, '.int': 0.95}
    
    def __init__(self):
        self._map = {}
        for score, domains in self.TIERS.items():
            for d in domains:
                self._map[d] = score
    
    def score(self, url: str) -> dict:
        domain = self._domain(url)
        score = 0.30
        if domain:
            for known, v in self._map.items():
                if domain == known or domain.endswith(f".{known}"):
                    score = v
                    break
            for tld, bonus in self.TLD_BONUS.items():
                if domain.endswith(tld):
                    score = max(score, bonus)
        return {
            "domain": domain,
            "score": round(score, 2),
            "is_credible": score >= 0.60,
            "authority": "High" if score >= 0.80 else "Medium" if score >= 0.60 else "Low",
        }
    
    def _domain(self, url: str) -> str:
        try:
            d = urlparse(url).netloc
            return d[4:] if d.startswith('www.') else d.lower()
        except:
            return ""

credibility = CredibilityManager()