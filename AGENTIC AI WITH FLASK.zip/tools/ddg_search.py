"""
tools/ddg_search.py
────────────────────
DuckDuckGo search using the unofficial API (free, no API key needed).
This uses the HTML endpoint which returns more results.
"""

import requests
import time
import json
import re
from pathlib import Path
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
from tools.credibility import credibility

REQUEST_DELAY = 0.5

# ── Cache setup ───────────────────────────────────────────────────────────────
CACHE_DIR = Path(__file__).resolve().parent.parent / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


class SearchCache:
    def __init__(self, ttl_hours=24):
        self.ttl = timedelta(hours=ttl_hours)
    
    def get(self, query: str) -> list[dict] | None:
        cache_file = CACHE_DIR / f"ddg_{hash(query)}.json"
        if cache_file.exists():
            try:
                data = json.loads(cache_file.read_text(encoding="utf-8"))
                timestamp = datetime.fromisoformat(data["timestamp"])
                if datetime.now() - timestamp < self.ttl:
                    return data["results"]
            except Exception:
                pass
        return None
    
    def set(self, query: str, results: list[dict]) -> None:
        cache_file = CACHE_DIR / f"ddg_{hash(query)}.json"
        try:
            cache_file.write_text(
                json.dumps({
                    "timestamp": datetime.now().isoformat(),
                    "query": query,
                    "results": results
                }, indent=2, ensure_ascii=False),
                encoding="utf-8"
            )
        except Exception as e:
            print(f"[Cache] Could not write cache: {e}")


search_cache = SearchCache()


def search_ddg(query: str, num_results: int = 10) -> list[dict]:
    """
    Search DuckDuckGo using the HTML endpoint (returns real search results).
    """
    # Check cache first
    cached = search_cache.get(query)
    if cached is not None:
        print(f"[DDG] Using cached results for '{query}'")
        return cached
    
    time.sleep(REQUEST_DELAY)
    
    results = []
    
    # Use the HTML endpoint which returns real search results
    url = "https://html.duckduckgo.com/html/"
    params = {
        "q": query,
        "s": "0",
        "dc": "0",
        "api": "d",
    }
    
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    try:
        resp = requests.get(url, params=params, headers=headers, timeout=15)
        resp.raise_for_status()
        
        soup = BeautifulSoup(resp.text, 'html.parser')
        
        # Find all result items
        result_items = soup.find_all('div', class_='result')
        
        for item in result_items[:num_results]:
            try:
                # Get title and link
                title_elem = item.find('a', class_='result__a')
                if not title_elem:
                    continue
                
                title = title_elem.get_text(strip=True)
                link = title_elem.get('href', '')
                
                # Get snippet
                snippet_elem = item.find('a', class_='result__snippet')
                if not snippet_elem:
                    snippet_elem = item.find('div', class_='result__snippet')
                
                snippet = snippet_elem.get_text(strip=True) if snippet_elem else ""
                
                # Get source/domain
                domain_elem = item.find('span', class_='result__url__domain')
                source = domain_elem.get_text(strip=True) if domain_elem else ""
                
                if link and title:
                    # Clean up the link (it's a redirect URL from DDG)
                    if link.startswith('//'):
                        link = 'https:' + link
                    elif link.startswith('/'):
                        link = 'https://duckduckgo.com' + link
                    
                    results.append({
                        "title": title,
                        "url": link,
                        "snippet": snippet,
                        "source": source or "DuckDuckGo",
                        "query": query,
                        "credibility": credibility.score(link),
                    })
            except Exception as e:
                continue
                
    except Exception as e:
        print(f"[DDG] Request failed: {e}")
        # Fallback to the API endpoint
        results = search_ddg_api(query, num_results)
    
    # Cache results
    if results:
        search_cache.set(query, results)
    
    print(f"[DDG] Found {len(results)} results for '{query}'")
    return results


def search_ddg_api(query: str, num_results: int = 10) -> list[dict]:
    """
    Fallback: Use the DuckDuckGo API endpoint.
    """
    params = {
        "q": query,
        "format": "json",
        "no_html": 1,
        "skip_disambig": 1,
    }
    
    try:
        resp = requests.get("https://api.duckduckgo.com/", params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        print(f"[DDG API] Request failed: {e}")
        return []
    
    results = []
    
    # Abstract
    if data.get("AbstractText"):
        url = data.get("AbstractURL", "")
        results.append({
            "title": data.get("AbstractSource", "DuckDuckGo"),
            "url": url,
            "snippet": data.get("AbstractText", ""),
            "source": data.get("AbstractSource", "DuckDuckGo"),
            "query": query,
            "credibility": credibility.score(url),
        })
    
    # Related Topics
    for item in data.get("RelatedTopics", [])[:num_results]:
        if "Text" in item and "FirstURL" in item:
            url = item.get("FirstURL", "")
            text = item.get("Text", "")
            title = text.split("-")[0].strip() if "-" in text else text[:60]
            results.append({
                "title": title,
                "url": url,
                "snippet": text,
                "source": "DuckDuckGo",
                "query": query,
                "credibility": credibility.score(url),
            })
    
    return results