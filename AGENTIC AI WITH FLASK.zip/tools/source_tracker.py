"""
tools/source_tracker.py
────────────────────────
Tracks every source (search hit) seen across a pipeline run.

Used by the Research Agent and Discovery Loop Agent to record which
query/context produced which URLs, deduplicate by URL, and expose a
pandas DataFrame (AgentState["all_sources_df"]) for downstream
analytics / saving.
"""

from typing import Any

import pandas as pd


class SourceTracker:
    """Collects and deduplicates sources discovered during a run."""

    def __init__(self) -> None:
        self._by_url: dict[str, dict[str, Any]] = {}

    def add(self, hits: list[dict], context: str = "") -> None:
        """
        Register a batch of search-result dicts (as returned by
        tools.serp_search.search_web / search_multiple).

        If a URL has already been seen, its `contexts` list is extended
        rather than duplicating the row.
        """
        for hit in hits:
            url = hit.get("url", "")
            if not url:
                continue

            if url in self._by_url:
                self._by_url[url]["contexts"].append(context)
                continue

            cred = hit.get("credibility", {}) or {}
            self._by_url[url] = {
                "url": url,
                "title": hit.get("title", ""),
                "source": hit.get("source", ""),
                "query": hit.get("query", ""),
                "domain": cred.get("domain", ""),
                "credibility_score": cred.get("score", 0),
                "is_credible": cred.get("is_credible", False),
                "contexts": [context],
            }

    def reset(self) -> None:
        """Clear all tracked sources — call at the start of a new run."""
        self._by_url.clear()

    def unique_count(self) -> int:
        return len(self._by_url)

    def unique_domains(self) -> set[str]:
        return {row["domain"] for row in self._by_url.values() if row["domain"]}

    def as_list(self) -> list[dict]:
        return list(self._by_url.values())

    def as_dataframe(self) -> pd.DataFrame:
        if not self._by_url:
            return pd.DataFrame(
                columns=[
                    "url", "title", "source", "query", "domain",
                    "credibility_score", "is_credible", "contexts",
                ]
            )
        return pd.DataFrame(self.as_list())


# ── Singleton used across agents ───────────────────────────────────────────
source_tracker = SourceTracker()
