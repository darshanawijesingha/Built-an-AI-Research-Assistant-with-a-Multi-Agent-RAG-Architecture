"""
tools/retriever.py
──────────────────
Hybrid retrieval pipeline:
  1. BM25 keyword search over raw web snippets
  2. Semantic scoring via sentence-transformers cosine similarity
  3. Reciprocal Rank Fusion (RRF) to merge both rankings
  4. Return top-k chunks

No external vector DB needed — we work directly on the web results
that the Research Agent already fetched via SerpAPI.
"""

import math
from typing import Optional

import numpy as np
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer, util

from config.settings import settings


# ── Load model once at import time ───────────────────────────────────────────
_EMBED_MODEL: Optional[SentenceTransformer] = None


def _get_embed_model() -> SentenceTransformer:
    global _EMBED_MODEL
    if _EMBED_MODEL is None:
        print("[Retriever] Loading sentence-transformer model (first run only)…")
        _EMBED_MODEL = SentenceTransformer("all-MiniLM-L6-v2")
    return _EMBED_MODEL


# ── Helpers ───────────────────────────────────────────────────────────────────

def _tokenize(text: str) -> list[str]:
    """Simple whitespace + lowercase tokenizer for BM25."""
    return text.lower().split()


def _rrf_score(rank: int, k: int = 60) -> float:
    """Reciprocal Rank Fusion score for a given rank (1-indexed)."""
    return 1.0 / (k + rank)


# ── Main retrieval function ───────────────────────────────────────────────────

def retrieve_top_chunks(
    question: str,
    documents: list[dict],
    top_k: int | None = None,
) -> list[dict]:
    """
    Given the user question and a list of raw web-result dicts
    (each with a 'snippet' key), return the top-k most relevant chunks
    after hybrid BM25 + semantic ranking.

    Each returned dict extends the input dict with:
        {
            "bm25_rank":      int,
            "semantic_rank":  int,
            "rrf_score":      float,
            "relevance":      float,   # 0–1, normalised RRF
        }
    """
    k = top_k or settings.TOP_K_CHUNKS

    if not documents:
        return []

    # ── Build text corpus ─────────────────────────────────────────────
    corpus = [f"{d.get('title', '')} {d.get('snippet', '')}" for d in documents]

    # ── 1. BM25 ───────────────────────────────────────────────────────
    tokenised_corpus = [_tokenize(c) for c in corpus]
    bm25 = BM25Okapi(tokenised_corpus)
    bm25_scores = bm25.get_scores(_tokenize(question))
    bm25_ranking = np.argsort(bm25_scores)[::-1].tolist()   # indices, best first

    # ── 2. Semantic similarity ────────────────────────────────────────
    model = _get_embed_model()
    q_emb = model.encode(question, convert_to_tensor=True)
    c_embs = model.encode(corpus, convert_to_tensor=True)
    cos_scores = util.cos_sim(q_emb, c_embs)[0].cpu().numpy()
    semantic_ranking = np.argsort(cos_scores)[::-1].tolist()  # indices, best first

    # ── 3. Reciprocal Rank Fusion ─────────────────────────────────────
    rrf: dict[int, float] = {}
    for rank, idx in enumerate(bm25_ranking, start=1):
        rrf[idx] = rrf.get(idx, 0.0) + _rrf_score(rank)
    for rank, idx in enumerate(semantic_ranking, start=1):
        rrf[idx] = rrf.get(idx, 0.0) + _rrf_score(rank)

    sorted_indices = sorted(rrf.keys(), key=lambda i: rrf[i], reverse=True)

    # ── 4. Normalise scores and annotate ─────────────────────────────
    max_rrf = max(rrf.values()) if rrf else 1.0

    results: list[dict] = []
    bm25_rank_map = {idx: rank for rank, idx in enumerate(bm25_ranking, start=1)}
    sem_rank_map  = {idx: rank for rank, idx in enumerate(semantic_ranking, start=1)}

    for idx in sorted_indices[:k]:
        doc = dict(documents[idx])   # copy so we don't mutate the original
        doc["bm25_rank"]     = bm25_rank_map.get(idx, len(corpus))
        doc["semantic_rank"] = sem_rank_map.get(idx, len(corpus))
        doc["rrf_score"]     = round(rrf[idx], 6)
        doc["relevance"]     = round(rrf[idx] / max_rrf, 4)
        results.append(doc)

    return results
