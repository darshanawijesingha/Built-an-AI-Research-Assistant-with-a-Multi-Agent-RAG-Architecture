"""
tools/serp_search.py
────────────────────
Thin wrapper around SerpAPI (Google Search).
Returns a clean list of result dicts the agents can consume directly.
"""

import time
import json
import requests
from pathlib import Path
from datetime import datetime, timedelta
from config.settings import settings
from tools.credibility import credibility


SERP_ENDPOINT = "https://serpapi.com/search"
REQUEST_DELAY = 1.5  # seconds between requests

# ── Cache setup ───────────────────────────────────────────────────────────────
CACHE_DIR = Path(__file__).resolve().parent.parent / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


class SearchCache:
    def __init__(self, ttl_hours=24):
        self.ttl = timedelta(hours=ttl_hours)
    
    def get(self, query: str) -> list[dict] | None:
        """Get cached results for a query if not expired."""
        cache_file = CACHE_DIR / f"{hash(query)}.json"
        if cache_file.exists():
            try:
                data = json.loads(cache_file.read_text(encoding="utf-8"))
                timestamp = datetime.fromisoformat(data["timestamp"])
                if datetime.now() - timestamp < self.ttl:
                    return data["results"]
            except Exception:
                pass
        return None
    
    def set(self, query: str, results: list[dict]) -> None:
        """Cache results for a query."""
        cache_file = CACHE_DIR / f"{hash(query)}.json"
        try:
            cache_file.write_text(
                json.dumps({
                    "timestamp": datetime.now().isoformat(),
                    "query": query,
                    "results": results
                }, indent=2, ensure_ascii=False),
                encoding="utf-8"
            )
        except Exception as e:
            print(f"[Cache] Could not write cache: {e}")


search_cache = SearchCache()


# ── Main search functions ─────────────────────────────────────────────────────

def search_web(query: str, num_results: int | None = None) -> list[dict]:
    """
    Run a Google search via SerpAPI.
    """
    # Check cache first
    cached = search_cache.get(query)
    if cached is not None:
        print(f"[SERP] Using cached results for '{query}'")
        return cached
    
    n = num_results or settings.MAX_SEARCH_RESULTS

    params = {
        "engine": "google",
        "q": query,
        "api_key": settings.SERP_API_KEY,
        "num": n,
        "hl": "en",
        "gl": "us",
    }

    try:
        # Add delay to avoid rate limits
        time.sleep(REQUEST_DELAY)
        
        resp = requests.get(SERP_ENDPOINT, params=params, timeout=15)
        resp.raise_for_status()
        data = resp.json()
    except requests.RequestException as e:
        print(f"[SERP] Request failed for query '{query}': {e}")
        return []

    results: list[dict] = []

    # ── Organic results ──────────────────────────────────────────────
    for item in data.get("organic_results", [])[:n]:
        link = item.get("link", "")
        results.append(
            {
                "title":       item.get("title", ""),
                "url":         link,
                "snippet":     item.get("snippet", ""),
                "source":      item.get("displayed_link", ""),
                "query":       query,
                "credibility": credibility.score(link),
            }
        )

    # ── Answer box (instant answer) ───────────────────────────────────
    answer_box = data.get("answer_box", {})
    if answer_box:
        snippet = (
            answer_box.get("answer")
            or answer_box.get("snippet")
            or answer_box.get("result", "")
        )
        if snippet:
            link = answer_box.get("link", "")
            results.insert(
                0,
                {
                    "title":       answer_box.get("title", "Answer Box"),
                    "url":         link,
                    "snippet":     snippet,
                    "source":      "Google Answer Box",
                    "query":       query,
                    "credibility": credibility.score(link),
                },
            )

    # Cache results
    if results:
        search_cache.set(query, results)
    
    return results


def search_multiple(queries: list[str]) -> list[dict]:
    """Run multiple queries and deduplicate by URL."""
    seen_urls: set[str] = set()
    all_results: list[dict] = []

    for q in queries:
        for result in search_web(q):
            if result["url"] not in seen_urls:
                seen_urls.add(result["url"])
                all_results.append(result)

    return all_results