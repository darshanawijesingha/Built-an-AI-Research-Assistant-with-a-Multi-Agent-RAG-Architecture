"""
tools/serp_search.py
────────────────────
Enhanced search wrapper with pagination for more results.
"""

import time
import json
import requests
from pathlib import Path
from datetime import datetime, timedelta
from config.settings import settings
from tools.credibility import credibility

SERP_ENDPOINT = "https://serpapi.com/search"
REQUEST_DELAY = 1.5  # Slightly longer delay for more results

# ── Cache setup ───────────────────────────────────────────────────────────────
CACHE_DIR = Path(__file__).resolve().parent.parent / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


class SearchCache:
    def __init__(self, ttl_hours=24):
        self.ttl = timedelta(hours=ttl_hours)
    
    def get(self, query: str) -> list[dict] | None:
        cache_file = CACHE_DIR / f"search_{hash(query)}.json"
        if cache_file.exists():
            try:
                data = json.loads(cache_file.read_text(encoding="utf-8"))
                timestamp = datetime.fromisoformat(data["timestamp"])
                if datetime.now() - timestamp < self.ttl:
                    return data["results"]
            except Exception:
                pass
        return None
    
    def set(self, query: str, results: list[dict]) -> None:
        cache_file = CACHE_DIR / f"search_{hash(query)}.json"
        try:
            cache_file.write_text(
                json.dumps({
                    "timestamp": datetime.now().isoformat(),
                    "query": query,
                    "results": results
                }, indent=2, ensure_ascii=False),
                encoding="utf-8"
            )
        except Exception as e:
            print(f"[Cache] Could not write cache: {e}")


search_cache = SearchCache()


def search_web(query: str, num_results: int | None = None, max_pages: int = 3) -> list[dict]:
    """
    Run a Google search via SerpAPI with pagination for more results.
    """
    # Check cache first
    cached = search_cache.get(query)
    if cached is not None:
        print(f"[Search] Using cached results for '{query}'")
        return cached
    
    n = num_results or settings.MAX_SEARCH_RESULTS
    
    # Check if API key is valid
    if not settings.SERP_API_KEY:
        print(f"[Search] No SerpAPI key found. Please add SERP_API_KEY to .env")
        return []

    all_results = []
    seen_urls = set()
    
    # Paginate through results
    for page in range(min(max_pages, 3)):  # Max 3 pages
        params = {
            "engine": "google",
            "q": query,
            "api_key": settings.SERP_API_KEY,
            "num": min(10, n),  # Max 10 per page in free tier
            "hl": "en",
            "gl": "us",
            "start": page * 10,  # Pagination offset
        }

        try:
            # Add delay to avoid rate limits
            if page > 0:
                time.sleep(REQUEST_DELAY)
            
            resp = requests.get(SERP_ENDPOINT, params=params, timeout=20)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            print(f"[Search] Error on page {page+1}: {e}")
            break

        # ── Organic results ──────────────────────────────────────────────
        for item in data.get("organic_results", []):
            link = item.get("link", "")
            if link and link not in seen_urls:
                seen_urls.add(link)
                all_results.append({
                    "title": item.get("title", ""),
                    "url": link,
                    "snippet": item.get("snippet", ""),
                    "source": item.get("displayed_link", ""),
                    "query": query,
                    "credibility": credibility.score(link),
                })
        
        # ── Answer box (instant answer) ───────────────────────────────────
        if page == 0:
            answer_box = data.get("answer_box", {})
            if answer_box:
                snippet = (
                    answer_box.get("answer")
                    or answer_box.get("snippet")
                    or answer_box.get("result", "")
                )
                if snippet:
                    link = answer_box.get("link", "")
                    all_results.insert(0, {
                        "title": answer_box.get("title", "Answer Box"),
                        "url": link,
                        "snippet": snippet,
                        "source": "Google Answer Box",
                        "query": query,
                        "credibility": credibility.score(link),
                    })

        # ── Related questions ─────────────────────────────────────────────
        if page == 0:
            for item in data.get("related_questions", [])[:3]:
                if item.get("link"):
                    all_results.append({
                        "title": item.get("question", "Related Question"),
                        "url": item.get("link", ""),
                        "snippet": item.get("snippet", ""),
                        "source": "Related Search",
                        "query": query,
                        "credibility": credibility.score(item.get("link", "")),
                    })

        # Check if we have enough results
        if len(all_results) >= n:
            break

    # Cache results
    if all_results:
        search_cache.set(query, all_results)
    
    print(f"[Search] Found {len(all_results)} unique results for '{query}'")
    return all_results[:n]


def search_multiple(queries: list[str], max_per_query: int = 15) -> list[dict]:
    """Run multiple queries and deduplicate by URL."""
    seen_urls: set[str] = set()
    all_results: list[dict] = []

    for q in queries:
        results = search_web(q, num_results=max_per_query)
        for result in results:
            url = result.get("url", "")
            if url and url not in seen_urls:
                seen_urls.add(url)
                all_results.append(result)

    # Sort by credibility
    all_results.sort(key=lambda x: x.get("credibility", {}).get("score", 0), reverse=True)
    
    return all_results