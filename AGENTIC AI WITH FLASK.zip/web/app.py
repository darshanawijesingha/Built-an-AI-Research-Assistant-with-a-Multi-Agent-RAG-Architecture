"""
web/app.py
──────────────────
Web interface for the Agentic AI Research System.
Wraps the existing pipeline in a Flask API.
"""
import os 
import sys
import json
import time
import uuid
from pathlib import Path
from datetime import datetime
from flask import Flask, request, jsonify, render_template, session
from flask_cors import CORS

# Add project root to path
project_root = Path(__file__).resolve().parent.parent
sys.path.append(str(project_root))

# Import your existing modules
from config.settings import settings
from core.pipeline import run_pipeline
from core.saver import OUTPUT_ROOT

# Initialize Flask
app = Flask(__name__)
app.secret_key = os.urandom(24)
CORS(app)

# Session storage for conversation history
sessions = {}

class WebSession:
    """Manages web session state"""
    
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.history = []
        self.created_at = datetime.now().isoformat()
    
    def add_query(self, question: str, result: dict):
        """Add a query and result to history"""
        self.history.append({
            "question": question,
            "result": result,
            "timestamp": datetime.now().isoformat()
        })
    
    def to_dict(self):
        return {
            "session_id": self.session_id,
            "created_at": self.created_at,
            "total_queries": len(self.history),
            "history": self.history
        }


@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')


@app.route('/api/ask', methods=['POST'])
def ask():
    """
    Process a question through the agentic pipeline
    Expects JSON: {"question": "...", "session_id": "..."}
    """
    try:
        data = request.get_json()
        question = data.get('question', '').strip()
        session_id = data.get('session_id', str(uuid.uuid4()))
        
        if not question:
            return jsonify({
                "success": False,
                "error": "Please enter a question"
            }), 400
        
        # Validate API keys
        try:
            settings.validate()
        except Exception as e:
            return jsonify({
                "success": False,
                "error": f"Configuration error: {str(e)}"
            }), 500
        
        # Run the pipeline
        print(f"\n🌐 Web request: {question}")
        start_time = time.time()
        
        try:
            result = run_pipeline(question)
            elapsed = time.time() - start_time
            
            # Extract key information
            response = {
                "success": True,
                "session_id": session_id,
                "question": question,
                "answer": result.get("final_answer", "No answer generated."),
                "validation": result.get("validation", {}),
                "analytics": result.get("analytics_result", {}),
                "search_queries": result.get("search_queries", []),
                "evidence_chunks": result.get("evidence_chunks", [])[:5],  # Only top 5 for display
                "run_id": result.get("run_id", "unknown"),
                "processing_time": round(elapsed, 2),
                "timestamp": datetime.now().isoformat()
            }
            
            # Store in session
            if session_id not in sessions:
                sessions[session_id] = WebSession(session_id)
            sessions[session_id].add_query(question, response)
            
            return jsonify(response)
            
        except Exception as e:
            print(f"❌ Pipeline error: {e}")
            import traceback
            traceback.print_exc()
            return jsonify({
                "success": False,
                "error": f"Pipeline error: {str(e)}"
            }), 500
            
    except Exception as e:
        print(f"❌ Request error: {e}")
        return jsonify({
            "success": False,
            "error": f"Server error: {str(e)}"
        }), 500


@app.route('/api/session/<session_id>', methods=['GET'])
def get_session(session_id):
    """Get session history"""
    if session_id in sessions:
        return jsonify(sessions[session_id].to_dict())
    return jsonify({"error": "Session not found"}), 404


@app.route('/api/sessions', methods=['GET'])
def list_sessions():
    """List all active sessions"""
    return jsonify({
        "sessions": [
            {
                "id": sid,
                "created": sess.created_at,
                "queries": len(sess.history)
            }
            for sid, sess in sessions.items()
        ]
    })


@app.route('/api/clear_session', methods=['POST'])
def clear_session():
    """Clear a session"""
    data = request.get_json()
    session_id = data.get('session_id')
    if session_id and session_id in sessions:
        sessions[session_id].history = []
        return jsonify({"success": True, "message": "Session cleared"})
    return jsonify({"error": "Session not found"}), 404


@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "model": settings.GROQ_MODEL,
        "max_results": settings.MAX_SEARCH_RESULTS,
        "top_k": settings.TOP_K_CHUNKS
    })


@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get system statistics"""
    stats = {
        "total_sessions": len(sessions),
        "total_queries": sum(len(sess.history) for sess in sessions.values()),
        "active_sessions": len([s for s in sessions.values() if s.history]),
        "timestamp": datetime.now().isoformat()
    }
    return jsonify(stats)


if __name__ == '__main__':
    print("\n" + "="*70)
    print("🌐 AGENTIC AI RESEARCH SYSTEM - WEB INTERFACE")
    print("="*70)
    print(f"📊 Model: {settings.GROQ_MODEL}")
    print(f"🔍 Max Search Results: {settings.MAX_SEARCH_RESULTS}")
    print(f"📝 Top K Chunks: {settings.TOP_K_CHUNKS}")
    print(f"🎯 Confidence Threshold: {settings.CONFIDENCE_THRESHOLD}")
    print("\n🧠 Agent Pipeline:")
    print("  ├── Supervisor → Research → Retrieval → Discovery")
    print("  ├── Analytics → Validation → Answer")
    print("\n🌐 Open in browser: http://localhost:5000")
    print("🔄 Press CTRL+C to stop")
    print("="*70 + "\n")
    
    app.run(debug=False, host='0.0.0.0', port=5000)