"""
core/pipeline.py
─────────────────
LangGraph pipeline — wires all agents together.

Flow:
  supervisor → research → retrieval → [analytics?] → validation → answer

The analytics node is conditional:
  • plan["needs_analytics"] == True  →  run Analytics Agent
  • otherwise                        →  skip directly to Validation
"""

from langgraph.graph import StateGraph, END

from core.state import AgentState
from agents.supervisor import supervisor_agent
from agents.research   import research_agent
from agents.retrieval  import retrieval_agent
from agents.discovery  import discovery_loop_agent
from agents.analytics  import analytics_agent
from agents.validation import validation_agent
from agents.answer     import answer_agent


# ── Conditional router ────────────────────────────────────────────────────────

def _should_run_analytics(state: AgentState) -> str:
    """Route to analytics if the supervisor flagged it, else skip."""
    plan = state.get("plan", {})
    if plan.get("needs_analytics", False):
        return "analytics"
    return "validation"


def _should_use_fallback(state: AgentState) -> str:
    """Check if we should use fallback when no search results exist."""
    chunks = state.get("evidence_chunks", [])
    raw_results = state.get("raw_results", [])
    
    # If no evidence chunks and no raw results, use fallback
    if not chunks and not raw_results:
        print("[Pipeline] No search results available. Using fallback.")
        return "fallback"
    
    # If we have chunks but they're all empty, also use fallback
    if chunks and all(not c.get("snippet") for c in chunks):
        print("[Pipeline] Empty evidence chunks. Using fallback.")
        return "fallback"
    
    return "discovery_loop"


# ── Build graph ───────────────────────────────────────────────────────────────

def build_pipeline() -> StateGraph:
    graph = StateGraph(AgentState)

    # ── Register nodes ────────────────────────────────────────────────
    graph.add_node("supervisor",     supervisor_agent)
    graph.add_node("research",       research_agent)
    graph.add_node("retrieval",      retrieval_agent)
    graph.add_node("discovery_loop", discovery_loop_agent)
    graph.add_node("analytics",      analytics_agent)
    graph.add_node("validation",     validation_agent)
    graph.add_node("answer",         answer_agent)
    
    # ── Fallback node (when no search results) ──────────────────────
    # This is a simple pass-through that uses the answer agent with no evidence
    def fallback_agent(state: AgentState) -> AgentState:
        """Fallback when no search results are available."""
        print("[Fallback] No search results. Will answer based on LLM knowledge.")
        # We'll let the answer agent handle this with a special prompt
        state["fallback_used"] = True
        return state
    
    graph.add_node("fallback", fallback_agent)

    # ── Fixed edges ───────────────────────────────────────────────────
    graph.set_entry_point("supervisor")
    graph.add_edge("supervisor",     "research")
    graph.add_edge("research",       "retrieval")
    
    # ── Conditional edge: check if we need fallback ──────────────────
    graph.add_conditional_edges(
        "retrieval",
        _should_use_fallback,
        {
            "fallback": "fallback",
            "discovery_loop": "discovery_loop",
        },
    )

    # ── Conditional edge: analytics or skip ───────────────────────────
    graph.add_conditional_edges(
        "discovery_loop",
        _should_run_analytics,
        {
            "analytics":  "analytics",
            "validation": "validation",
        },
    )

    graph.add_edge("analytics",  "validation")
    graph.add_edge("validation", "answer")
    graph.add_edge("answer",     END)
    
    # ── Fallback path ─────────────────────────────────────────────────
    graph.add_edge("fallback", "answer")

    return graph.compile()


# ── Public API ────────────────────────────────────────────────────────────────

def run_pipeline(question: str) -> dict:
    """
    Run the full agentic pipeline for a given question.
    Auto-saves all outputs to outputs/ after every run.

    Returns the final AgentState dict which includes:
        - final_answer   : str
        - validation     : dict  (confidence score etc.)
        - evidence_chunks: list
        - search_queries : list
        - run_id         : str   (injected after save)
    """
    from core.saver import save_run          # local import to avoid circular deps
    from tools.source_tracker import source_tracker

    # Reset the source tracker so each run starts clean
    source_tracker.reset()

    pipeline = build_pipeline()
    initial_state: AgentState = {"user_question": question}
    result = pipeline.invoke(initial_state)

    # Expose all sources tracked during this run.
    result["all_sources_df"] = source_tracker.as_dataframe()

    # ── Auto-save everything ──────────────────────────────────────────
    run_id = save_run(result)
    result["run_id"] = run_id

    return result