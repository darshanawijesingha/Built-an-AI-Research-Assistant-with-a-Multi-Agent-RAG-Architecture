"""
core/saver.py
──────────────
Auto-save system.  Called after every pipeline run.

Folder structure created automatically:
    outputs/
    ├── sessions/
    │   └── session_20250623_143201.json     ← full session history
    ├── runs/
    │   └── run_20250623_143201_abc12.json   ← one file per question
    ├── evidence/
    │   └── evidence_20250623_143201_abc12.json
    ├── analytics/
    │   └── analytics_20250623_143201_abc12.json
    └── summary_index.json                   ← master index of all runs
"""

import json
import os
import re
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

# ── Output root (sits next to main.py) ───────────────────────────────────────
OUTPUT_ROOT = Path(__file__).resolve().parent.parent / "outputs"


def _ensure_dirs() -> None:
    """Create all output subdirectories if they don't exist."""
    for sub in ["sessions", "runs", "evidence", "analytics", "data", "case_studies"]:
        (OUTPUT_ROOT / sub).mkdir(parents=True, exist_ok=True)


def _run_id() -> str:
    """Short unique ID for this run: timestamp + 5-char uuid."""
    ts  = datetime.now().strftime("%Y%m%d_%H%M%S")
    uid = uuid.uuid4().hex[:5]
    return f"{ts}_{uid}"


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _safe_write(path: Path, data: dict) -> None:
    """Write JSON safely — never crash the main pipeline."""
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False, default=str)
    except Exception as e:
        print(f"[Saver] ⚠️  Could not write {path.name}: {e}")


# ── Master index helpers ──────────────────────────────────────────────────────

def _load_index() -> dict:
    index_path = OUTPUT_ROOT / "summary_index.json"
    if index_path.exists():
        try:
            return json.loads(index_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"total_runs": 0, "runs": []}


def _update_index(run_id: str, question: str, confidence: float,
                  confidence_label: str, n_sources: int,
                  run_file: str) -> None:
    index = _load_index()
    index["total_runs"] = index.get("total_runs", 0) + 1
    index["last_updated"] = _now_iso()
    index["runs"].append({
        "run_id":           run_id,
        "timestamp":        _now_iso(),
        "question":         question,
        "confidence_score": confidence,
        "confidence_label": confidence_label,
        "unique_sources":   n_sources,
        "run_file":         run_file,
    })
    _safe_write(OUTPUT_ROOT / "summary_index.json", index)


# ── Session manager ───────────────────────────────────────────────────────────

_SESSION_ID:   Optional[str]  = None
_SESSION_PATH: Optional[Path] = None
_SESSION_DATA: dict           = {}


def _get_session_path() -> Path:
    global _SESSION_ID, _SESSION_PATH, _SESSION_DATA
    if _SESSION_PATH is None:
        _SESSION_ID   = datetime.now().strftime("session_%Y%m%d_%H%M%S")
        _SESSION_PATH = OUTPUT_ROOT / "sessions" / f"{_SESSION_ID}.json"
        _SESSION_DATA = {
            "session_id":  _SESSION_ID,
            "started_at":  _now_iso(),
            "total_questions": 0,
            "questions": [],
        }
    return _SESSION_PATH


def _append_to_session(question: str, answer: str, run_id: str,
                        confidence: float, confidence_label: str) -> None:
    path = _get_session_path()
    _SESSION_DATA["total_questions"] += 1
    _SESSION_DATA["last_updated"]     = _now_iso()
    _SESSION_DATA["questions"].append({
        "run_id":           run_id,
        "timestamp":        _now_iso(),
        "question":         question,
        "answer":           answer,
        "confidence_score": confidence,
        "confidence_label": confidence_label,
    })
    _safe_write(path, _SESSION_DATA)


# ── Main public function ──────────────────────────────────────────────────────

def save_run(state: dict) -> str:
    """
    Save all pipeline outputs for one question.
    Returns the run_id so main.py can display it.

    Files written:
        outputs/runs/run_<id>.json          ← full run (question + answer + meta)
        outputs/evidence/evidence_<id>.json ← evidence chunks + sources
        outputs/analytics/analytics_<id>.json (only if analytics ran)
        outputs/sessions/session_<ts>.json  ← appended to current session
        outputs/summary_index.json          ← master index updated
    """
    _ensure_dirs()
    run_id = _run_id()

    question   = state.get("user_question", "")
    answer     = state.get("final_answer", "")
    plan       = state.get("plan", {})
    queries    = state.get("search_queries", [])
    chunks     = state.get("evidence_chunks", [])
    analytics  = state.get("analytics_result")
    validation = state.get("validation", {})

    confidence       = validation.get("confidence_score", 0.0)
    confidence_label = validation.get("confidence_label", "Unknown")
    n_sources        = validation.get("unique_sources", 0)

    # ── 1. Full run file ──────────────────────────────────────────────
    run_data = {
        "run_id":        run_id,
        "timestamp":     _now_iso(),
        "question":      question,
        "answer":        answer,
        "plan":          plan,
        "search_queries": queries,
        "validation": {
            "confidence_score":  confidence,
            "confidence_label":  confidence_label,
            "unique_sources":    n_sources,
            "source_domains":    validation.get("source_domains", []),
            "agreement_level":   validation.get("agreement_level", ""),
            "agreement_reason":  validation.get("agreement_reason", ""),
            "total_chunks_used": validation.get("total_chunks_used", 0),
        },
        "has_analytics": analytics is not None,
    }
    run_file = f"run_{run_id}.json"
    _safe_write(OUTPUT_ROOT / "runs" / run_file, run_data)

    # ── 2. Evidence file ──────────────────────────────────────────────
    evidence_data = {
        "run_id":         run_id,
        "timestamp":      _now_iso(),
        "question":       question,
        "total_chunks":   len(chunks),
        "evidence_chunks": [
            {
                "rank":          i + 1,
                "title":         c.get("title", ""),
                "url":           c.get("url", ""),
                "source":        c.get("source", ""),
                "snippet":       c.get("snippet", ""),
                "query":         c.get("query", ""),
                "relevance":     c.get("relevance", 0),
                "bm25_rank":     c.get("bm25_rank"),
                "semantic_rank": c.get("semantic_rank"),
                "rrf_score":     c.get("rrf_score"),
            }
            for i, c in enumerate(chunks)
        ],
    }
    _safe_write(OUTPUT_ROOT / "evidence" / f"evidence_{run_id}.json", evidence_data)

    # ── 3. Analytics file (only if analytics ran) ─────────────────────
    if analytics:
        analytics_data = {
            "run_id":    run_id,
            "timestamp": _now_iso(),
            "question":  question,
            **analytics,
        }
        _safe_write(
            OUTPUT_ROOT / "analytics" / f"analytics_{run_id}.json",
            analytics_data,
        )

    # ── 4. Append to session ──────────────────────────────────────────
    _append_to_session(question, answer, run_id, confidence, confidence_label)

    # ── 5. Update master index ────────────────────────────────────────
    _update_index(run_id, question, confidence, confidence_label,
                  n_sources, run_file)

        # Save case studies
    case_studies = state.get("case_studies", {})
    for dim, studies in case_studies.items():
        dim_dir = OUTPUT_ROOT / "case_studies" / dim
        dim_dir.mkdir(parents=True, exist_ok=True)
        for entity, text in studies.items():
            safe_entity = re.sub(r'[^\w\-]', '_', entity)[:40]
            _safe_write(dim_dir / f"{safe_entity}_{run_id}.txt", text)
    
    # Save entities
    _safe_write(OUTPUT_ROOT / "data" / f"entities_{run_id}.json", {
        "entities": state.get("entities", []),
        "entity_data": {
            k: {"n_hits": v.get("n_hits", 0), "queries": v.get("queries", [])}
            for k, v in (state.get("entity_deep_data") or {}).items()
        }
    })
    
    return run_id
