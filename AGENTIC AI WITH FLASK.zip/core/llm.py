"""
core/llm.py
───────────
Thin singleton wrapper around the Groq chat model.
Import `llm` anywhere you need to call the model directly,
or use `call_llm(system, user)` for a simple one-shot call.
"""

import json
from langchain_groq import ChatGroq
from langchain_core.messages import SystemMessage, HumanMessage
from config.settings import settings


# ── Singleton ────────────────────────────────────────────────────────────────
llm = ChatGroq(
    api_key=settings.GROQ_API_KEY,
    model=settings.GROQ_MODEL,
    temperature=0.1,          # low temp → deterministic, factual answers
    max_tokens=4096,
)


def call_llm(system_prompt: str, user_prompt: str) -> str:
    """One-shot LLM call.  Returns the raw text response."""
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt),
    ]
    response = llm.invoke(messages)
    return response.content.strip()


def call_llm_json(system_prompt: str, user_prompt: str) -> dict:
    """
    One-shot LLM call that expects a JSON response.
    Strips markdown fences before parsing.
    Falls back to an empty dict on parse failure.
    """
    raw = call_llm(system_prompt, user_prompt)
    # strip ```json ... ``` fences if present
    clean = raw.strip()
    if clean.startswith("```"):
        clean = clean.split("```")[1]
        if clean.startswith("json"):
            clean = clean[4:]
    try:
        return json.loads(clean)
    except json.JSONDecodeError:
        return {}
