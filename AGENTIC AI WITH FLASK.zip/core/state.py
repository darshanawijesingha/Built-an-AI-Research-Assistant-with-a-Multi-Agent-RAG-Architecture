"""
core/state.py
─────────────
Typed state object that flows through every node in the LangGraph pipeline.
Each agent reads what it needs and writes its own output key.
"""

from typing import Any, Optional
from typing_extensions import TypedDict
import pandas as pd

class AgentState(TypedDict, total=False):
    # ── Input ─────────────────────────────────────────────────────────
    user_question: str                  # raw question from the user

    # ── Supervisor ────────────────────────────────────────────────────
    plan: dict[str, Any]               # routing decisions

    # ── Research Agent ────────────────────────────────────────────────
    search_queries: list[str]          # generated search queries

    # ── Retrieval Agent ───────────────────────────────────────────────
    raw_results: list[dict]            # all SERP results
    evidence_chunks: list[dict]        # top-k re-ranked chunks

    # ── Analytics Agent ───────────────────────────────────────────────
    analytics_result: Optional[dict]   # stats / trends (if needed)

    # ── Validation Agent ──────────────────────────────────────────────
    validation: dict[str, Any]         # confidence score + cross-check

    # ── Answer Agent ──────────────────────────────────────────────────
    final_answer: str   
    
    entities: list[str]          # Auto-discovered entities
    entity_deep_data: dict[str, dict]       # Deep evidence per entity
    dimensions: list[str]                   # Case study dimensions
    case_studies: dict[str, dict]           # Generated case studies
    evidence_stats: dict[str, dict]         # Per-entity evidence stats
    analytics: dict[str, dict]              # Enhanced analytics
    all_sources_df: Optional[pd.DataFrame]  # Source tracking
               # the response shown to the user

    # ── Meta ──────────────────────────────────────────────────────────
    error: Optional[str]               # propagated error message

