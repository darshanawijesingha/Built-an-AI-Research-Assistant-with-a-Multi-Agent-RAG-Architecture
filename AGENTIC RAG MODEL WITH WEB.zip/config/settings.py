"""
config/settings.py
──────────────────
Central configuration loader.
"""

import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    # ── LLM ──────────────────────────────────────────────────────────
    GROQ_API_KEY: str = os.getenv("GROQ_API_KEY", "")
    GROQ_MODEL: str = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

    # ── Search ───────────────────────────────────────────────────────
    SERP_API_KEY: str = os.getenv("SERP_API_KEY", "")
    MAX_SEARCH_RESULTS: int = int(os.getenv("MAX_SEARCH_RESULTS", "30"))  # Increased to 30
    MAX_SEARCH_QUERIES: int = int(os.getenv("MAX_SEARCH_QUERIES", "6"))   # More queries
    
    # ── Retrieval ────────────────────────────────────────────────────
    TOP_K_CHUNKS: int = int(os.getenv("TOP_K_CHUNKS", "20"))  # More chunks
    CONFIDENCE_THRESHOLD: float = float(os.getenv("CONFIDENCE_THRESHOLD", "0.6"))

    # ── Validation ───────────────────────────────────────────────────
    MIN_SOURCES_FOR_HIGH_CONFIDENCE: int = 5  # Higher threshold

    def validate(self) -> None:
        """Raise early if required keys are missing."""
        missing = []
        if not self.GROQ_API_KEY:
            missing.append("GROQ_API_KEY")
        if not self.SERP_API_KEY:
            print("\n⚠️  WARNING: SERP_API_KEY not set in .env file!")
            print("   Get a free API key at: https://serpapi.com/")
            print("   Add it to .env: SERP_API_KEY=your_key_here\n")
        if missing:
            raise EnvironmentError(
                f"Missing required environment variables: {', '.join(missing)}\n"
                "Copy .env.example → .env and fill in your keys."
            )


settings = Settings()