# 🤖 Agentic AI Research System

> **User asks a question → AI finds the best evidence → analyses it → returns a confident answer.**

Built with **LangGraph**, **Groq LLM**, and **SerpAPI** (Google Search).

---

## Architecture

```
USER QUESTION
      │
      ▼
┌─────────────────┐
│ Supervisor Agent │  ← decides routing plan
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Research Agent  │  ← generates search queries → SerpAPI
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Retrieval Agent  │  ← BM25 + Semantic + RRF re-ranking
└────────┬────────┘
         │
    [if analytics needed]
         │
         ▼
┌─────────────────┐
│ Analytics Agent  │  ← stats, trends, number extraction
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│Validation Agent  │  ← confidence score + cross-check
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Answer Agent    │  ← synthesises final structured answer
└────────┬────────┘
         │
         ▼
    RESPONSE
```

---

## Quick Start

### 1. Clone / copy this project

```bash
cd agentic_ai
```

### 2. Create virtual environment

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Set up API keys

```bash
cp .env.example .env
# Edit .env and add your keys:
#   GROQ_API_KEY=...   → https://console.groq.com/keys
#   SERP_API_KEY=...   → https://serpapi.com/manage-api-key
```

### 5. Run

```bash
# Interactive mode (ask multiple questions)
python main.py

# Single question
python main.py --question "Why are elevator sales declining in Sri Lanka?"

# Run demo questions
python main.py --demo
```

---

## Agent Responsibilities

| Agent | Input | Output |
|-------|-------|--------|
| **Supervisor** | User question | Routing plan (JSON) |
| **Research** | Plan + question | 3–5 search queries + raw SERP results |
| **Retrieval** | Raw results | Top-10 re-ranked evidence chunks |
| **Analytics** | Evidence chunks | Stats, trends, numerical insights *(conditional)* |
| **Validation** | Evidence + analytics | Confidence score (0–1) + agreement level |
| **Answer** | All of the above | Structured final answer |

---

## Retrieval Pipeline Detail

```
User Question
      │
      ▼
BM25 Keyword Search   ← fast, exact keyword matching
      │
      ▼
Semantic Search       ← all-MiniLM-L6-v2 cosine similarity
      │
      ▼
RRF Fusion            ← Reciprocal Rank Fusion merges both rankings
      │
      ▼
Top-K Chunks          ← best 10 evidence pieces sent to Answer Agent
```

---

## Analytics Agent (Conditional)

Triggered when the Supervisor detects numerical questions:

- Revenue trends / Growth % / Market size
- Churn rates / Customer segmentation
- Any question with "how much", "percentage", "trend", "increase", "decline"

Computes:
- Descriptive statistics (mean, median, min, max, stdev)
- Linear trend direction (increasing / decreasing / stable)
- LLM-extracted structured stats from snippets

---

## Confidence Scoring

| Condition | Score Added |
|-----------|-------------|
| Base score | +0.40 |
| ≥ 3 unique source domains | +0.20 |
| Sources agree (high agreement) | +0.20 |
| Sources partially agree | +0.10 |
| ≥ 5 evidence chunks | +0.10 |
| Analytics data available | +0.10 |
| **Max possible** | **1.00** |

Labels: **High** (≥0.80) · **Moderate** (0.60–0.79) · **Low** (<0.60)

---

## Tech Stack

| Component | Library |
|-----------|---------|
| Multi-agent orchestration | `langgraph` |
| LLM | `langchain-groq` + `groq` (llama-3.3-70b) |
| Web search | `serpapi` (Google) |
| Keyword retrieval | `rank-bm25` |
| Semantic retrieval | `sentence-transformers` (all-MiniLM-L6-v2) |
| Stats / analytics | `pandas`, `numpy`, `scikit-learn` |
| CLI output | `rich` |
| Config | `python-dotenv` |

---

## Project Structure

```
agentic_ai/
├── main.py                  ← CLI entry point
├── requirements.txt
├── .env.example             ← copy to .env and fill keys
├── README.md
│
├── config/
│   └── settings.py          ← central config loader
│
├── core/
│   ├── state.py             ← AgentState TypedDict
│   ├── llm.py               ← Groq LLM wrapper
│   └── pipeline.py          ← LangGraph graph builder
│
├── agents/
│   ├── supervisor.py        ← routing plan
│   ├── research.py          ← query generation + SERP
│   ├── retrieval.py         ← BM25 + semantic + RRF
│   ├── analytics.py         ← stats + trend analysis
│   ├── validation.py        ← confidence scoring
│   └── answer.py            ← final answer synthesis
│
└── tools/
    ├── serp_search.py       ← SerpAPI wrapper
    └── retriever.py         ← hybrid retrieval engine
```

---

## Example Output

```
Question: Why are elevator sales declining in Sri Lanka?

Pipeline Summary
┌──────────────────────────────┬─────────────────────────┐
│ Search queries executed      │ 4                       │
│ Evidence chunks retrieved    │ 10                      │
│ Unique source domains        │ 7                       │
│ Source agreement             │ High                    │
│ Confidence                   │ High (0.90)             │
│ Total time                   │ 8.3s                    │
└──────────────────────────────┴─────────────────────────┘

## Answer
Elevator sales in Sri Lanka have declined primarily due to...

## Key Findings
- Construction activity dropped by 34% in 2023–2024
- Foreign currency shortages limited equipment imports
- ...

## Confidence
High (0.90) — Multiple authoritative sources agree on primary drivers.
```

---

## Extending the System

**Add document search (PDFs / Excel):**
- Add a `DocumentLoader` tool in `tools/`
- Chunk + embed documents into ChromaDB
- Update `retrieval_agent` to merge DB results with SERP results

**Add forecasting:**
- Install `prophet`, `statsmodels`
- Extend `analytics_agent` to call Prophet when `needs_forecast=True`

**Add a web UI:**
- Wrap `run_pipeline()` in a FastAPI endpoint
- Build a React frontend that calls the API
